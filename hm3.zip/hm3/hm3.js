// // 1. a.

// let fruits = ["apple", "banana", "orange"];

// console.log(fruits[1]);
// fruits.push("peach");
// console.log(fruits);

// // b.


// let randomObject = {

// name: "Miki",
// age : 28,
// city: "Skopje"

// }

// console.log (randomObject.city);
// console.log( randomObject.age);

// console.log( fruits, randomObject)
 
// 2. a.

// for (let i=0; i<=10; i++) {
//     console.log(i)
// }


//b.

// let start = 3;
// let end = 10;
// let sumOfEvenNumbers = 0;

// for (let i= start; i<=end; i++) {
//     if(i % 2 === 0) {
//         sumOfEvenNumbers +=1;
//     }
// }

// console.log(sumOfEvenNumbers)


// v. 

// let person = {
//     name: "Miki",
//     age:28,
//     city: "Skopje"

// }

// for (let x in person) {
//     console.log (x + ":" + person[x])
// }

// // g. 
// let colors = ["red","green", "blue"]
//  for (let color of colors) {
//     console.log (`${color.length} ${color}`)
//  }



// 3. a.


// let count = 5; 
// while (count >=1) {
//     console.log (count);
//     count--;
// }


// b. 

// let count = 10; 
// do {
//     console.log(count);
//     count--;
// } while (count >= 5)


// // 4. a.

// function multiply (num1,num2) {
//     return num1 * num2;

// }

// let result = multiply(3,5);
// console.log(result)


// //b. 

// function divideFunction (num1,num2) {
//     return num1 / num2;

// }

// let divide = divideFunction(10,2);
// console.log(divide)


// // v. 

// const substract = (x,y) => x-y;
// const result = substract (8,5);
// console.log(result)


// // 4. 

// function calculateArraySum(numbersArray) { 
//     let sum = 0; 
//     for( let number of numbersArray) {
//         sum += number;
//     }
//     return sum;

// }

// const randomArray = [1,2,3,4,5];
// const result = calculateArraySum(randomArray);
// console.log(result)


// // 5. 

// let students = [
// {
//  name: "Miki",
//  surname: "Stojanovski",
//  age: 28,
//  address :{
//     city: "Skopje",
//     street: {
//         name: "randomName",
//         number: 100
//     },
//     zipCode: 1000
//  },
// },
// {
//     name: "Martin",
//     surname: "Stojanovski",
//     age: 35,
//     address :{
//        city: "Bitola",
//        street: {
//            name: "randomName",
//            number: 250
//        },
//        zipCode: 1000
//     },
//    }

// ]

// console.log (students[0].address.city);
// console.log(students[1]["address"]["street"]["name"]);


// // 7. a.


// function checkFizzBuzz (number) {
//     if (number % 3 === 0 && number % 5 === 0 ) {
//         console.log("FizzBuzz");
//     } else if ( number % 3 === 0 ) {
//         console.log ("Fizz");
//     } else if ( number % 5 === 0 ) {
//         console.log("Buzz")
//     } else {
//         console.log(number);
//     }
// }

// checkFizzBuzz(10);

// //b. 

// function randomFunction (month) {

//     switch(month.toLowerCase()) {

//         case "january":
//             case "march":
//                 case "may":
//                     case "july":
//                         case "august":
//                             case "october":
//                                 case "december":
//                                     return 31;
//                                     case "april":
//                                         case "june":
//                                             case "september":
//                                                 case "november":
//                                                     return 30;
//                                                     case "february":
//                                                         return 28;
//                                                         default :
//                                                         console.log("Invalid input");
//                                                         return 10;




//     }
// }

// console.log(randomFunction ("August"));


// 8. 

// //a. 

// let goodBook = {
//     name: "OnceUponATime",
//     pages: 1000,
//     author :{ 
//         name: "nameOfTheAuthor",
//         surname: "surnameOfTheAuthor"
//     },
//     price: 100
// };


// //b. 

// let goodCar = {

//     model : "BMW",
//     power : "bigPower",
//     engine : "veryGoodEngine",
//     price: {
//         withoutDiscount: "150000eur",
//         withDiscount: "149999eur"
//     }
// };


// // v. 

// let student = {
//  name: "Miki",
//  surname: "Stojanovski",
//  age: 28,
//  address :{
//     city: "Skopje",
//     street: {
//         name: "randomName",
//         number: 100
//     },
//     zipCode: 1000
//  }
// }



// 9. a. 


// let j = 0;

// for ( let i = 1; i <= 100; i++) {
//     if (i % 2 !==0 ) {
//         j++;
//         if ( j === 2 ) {
//             console.log(i);
//             j = 0;
//         }
//     } 
// }

// //b. 

// for(let i = 1; i<=50; i++){
// if(i % 2 === 0) {
//     console.log(i)
// }

// }