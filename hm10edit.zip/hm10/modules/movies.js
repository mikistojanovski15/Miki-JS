export const movies = [
  "The Shawshank Redemption",
  "Se7en",
  "Prisoners",
  "The Usual Suspects",
  "Zodiac",
];
