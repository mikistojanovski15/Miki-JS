import { movies } from "./movies.js";

document.addEventListener("DOMContentLoaded", function () {
  const moviesList = document.getElementById("moviesList");

  if (movies && movies.length > 0) {
    const moviesUl = document.createElement("ul");

    movies.forEach((movie) => {
      const movieLi = document.createElement("li");
      movieLi.textContent = movie;
      moviesUl.appendChild(movieLi);
    });

    moviesList.appendChild(moviesUl);
  } else {
    moviesList.textContent = "No movies found.";
  }
});
